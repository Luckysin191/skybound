package com.skybound;

import com.skybound.registry.ModBlocks;
import com.skybound.registry.ModCreativeTabs;
import com.skybound.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SkyboundMod implements ModInitializer {
    public static final String MOD_ID = "skybound";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** data/skybound/dimension/skyreach.json */
    public static final ResourceKey<Level> SKYREACH =
            ResourceKey.create(Registries.DIMENSION, id("skyreach"));

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.register();   // blocks + their block items (must come first)
        ModItems.register();
        ModCreativeTabs.register();
        LOGGER.info("Skybound loaded.");
    }
}
