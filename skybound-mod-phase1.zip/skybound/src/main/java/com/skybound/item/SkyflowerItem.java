package com.skybound.item;

import com.skybound.SkyboundMod;
import com.skybound.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

/** Right-click: travel between the Overworld and the Skyreach (phase-1 stand-in for a real portal). */
public class SkyflowerItem extends Item {
    public SkyflowerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel from) || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResult.SUCCESS;
        }

        boolean toSky = from.dimension() != SkyboundMod.SKYREACH;
        ServerLevel dest = from.getServer().getLevel(toSky ? SkyboundMod.SKYREACH : Level.OVERWORLD);
        if (dest == null) {
            serverPlayer.sendSystemMessage(Component.literal("The Skyreach dimension could not be loaded."));
            return InteractionResult.FAIL;
        }

        BlockPos target;
        if (toSky) {
            target = new BlockPos(0, 90, 0);
            buildPlatform(dest, target);
        } else {
            int y = dest.getHeight(Heightmap.Types.MOTION_BLOCKING, 0, 0);
            target = new BlockPos(0, y, 0);
        }

        serverPlayer.teleport(new TeleportTransition(dest, Vec3.atBottomCenterOf(target), Vec3.ZERO,
                serverPlayer.getYRot(), serverPlayer.getXRot(), TeleportTransition.DO_NOTHING));

        if (!serverPlayer.hasInfiniteMaterials()) {
            serverPlayer.getItemInHand(hand).shrink(1);
        }
        return InteractionResult.SUCCESS;
    }

    private static void buildPlatform(ServerLevel dest, BlockPos center) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                dest.setBlock(center.offset(dx, -1, dz), ModBlocks.CLOUDSTONE.defaultBlockState(), Block.UPDATE_ALL);
                for (int dy = 0; dy <= 2; dy++) {
                    dest.setBlock(center.offset(dx, dy, dz), Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                }
            }
        }
    }
}
