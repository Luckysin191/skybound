package com.skybound.registry;

import com.skybound.SkyboundMod;
import com.skybound.item.SkyflowerItem;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;

public final class ModItems {
    private ModItems() {}

    public static Item CHRONOSHARD;
    public static Item SKYFLOWER;
    public static Item GLAIVE;

    public static void register() {
        CHRONOSHARD = registerItem("chronoshard", Item::new, new Item.Properties());
        SKYFLOWER = registerItem("skyflower", SkyflowerItem::new, new Item.Properties().stacksTo(16));
        // Heavy iron-tier weapon: high damage, slow swing. (Extended reach comes in a later phase.)
        GLAIVE = registerItem("glaive", Item::new, new Item.Properties().sword(ToolMaterial.IRON, 5.0f, -3.0f));
    }

    private static <T extends Item> T registerItem(String name, Function<Item.Properties, T> factory,
                                                   Item.Properties properties) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, SkyboundMod.id(name));
        T item = factory.apply(properties.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }
}
