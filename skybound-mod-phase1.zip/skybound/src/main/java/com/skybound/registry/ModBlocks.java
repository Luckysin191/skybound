package com.skybound.registry;

import com.skybound.SkyboundMod;
import com.skybound.block.VerticalSlabBlock;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public final class ModBlocks {
    private ModBlocks() {}

    /** Every block registered here (used to fill the creative tab). */
    public static final List<Block> ALL = new ArrayList<>();

    public static Block CLOUDSTONE;
    public static Block STORM_CLOUDSTONE;
    public static Block CLOUDSTONE_BRICKS;
    public static Block STARGLASS;
    public static Block ZEPHYR_CRYSTAL;
    public static Block SKYROOT_PLANKS;

    public static void register() {
        CLOUDSTONE = registerBlock("cloudstone", Block::new,
                BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.5f, 6.0f).sound(SoundType.STONE));
        STORM_CLOUDSTONE = registerBlock("storm_cloudstone", Block::new,
                BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(2.0f, 6.0f).sound(SoundType.STONE));
        CLOUDSTONE_BRICKS = registerBlock("cloudstone_bricks", Block::new,
                BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.5f, 6.0f).sound(SoundType.STONE));
        STARGLASS = registerBlock("starglass", Block::new,
                BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(0.4f).sound(SoundType.GLASS)
                        .noOcclusion().lightLevel(state -> 6));
        ZEPHYR_CRYSTAL = registerBlock("zephyr_crystal", Block::new,
                BlockBehaviour.Properties.of().mapColor(MapColor.DIAMOND).strength(1.0f).sound(SoundType.AMETHYST)
                        .lightLevel(state -> 10));
        SKYROOT_PLANKS = registerBlock("skyroot_planks", Block::new,
                BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0f, 3.0f).sound(SoundType.WOOD));

        // Vertical slabs. Keys MUST match VSLABS in gen_resources.py (ids = <key>_vertical_slab).
        Map<String, Block> bases = new LinkedHashMap<>();
        bases.put("stone", Blocks.STONE);
        bases.put("cobblestone", Blocks.COBBLESTONE);
        bases.put("stone_bricks", Blocks.STONE_BRICKS);
        bases.put("bricks", Blocks.BRICKS);
        bases.put("nether_bricks", Blocks.NETHER_BRICKS);
        bases.put("end_stone_bricks", Blocks.END_STONE_BRICKS);
        bases.put("deepslate_bricks", Blocks.DEEPSLATE_BRICKS);
        bases.put("purpur_block", Blocks.PURPUR_BLOCK);
        bases.put("oak_planks", Blocks.OAK_PLANKS);
        bases.put("spruce_planks", Blocks.SPRUCE_PLANKS);
        bases.put("birch_planks", Blocks.BIRCH_PLANKS);
        bases.put("jungle_planks", Blocks.JUNGLE_PLANKS);
        bases.put("acacia_planks", Blocks.ACACIA_PLANKS);
        bases.put("dark_oak_planks", Blocks.DARK_OAK_PLANKS);
        bases.put("mangrove_planks", Blocks.MANGROVE_PLANKS);
        bases.put("cherry_planks", Blocks.CHERRY_PLANKS);
        bases.put("bamboo_planks", Blocks.BAMBOO_PLANKS);
        bases.put("cloudstone", CLOUDSTONE);
        bases.put("storm_cloudstone", STORM_CLOUDSTONE);
        bases.put("cloudstone_bricks", CLOUDSTONE_BRICKS);
        bases.put("skyroot_planks", SKYROOT_PLANKS);

        bases.forEach((name, base) -> registerBlock(name + "_vertical_slab", VerticalSlabBlock::new,
                BlockBehaviour.Properties.ofFullCopy(base)));
    }

    private static <T extends Block> T registerBlock(String name, Function<BlockBehaviour.Properties, T> factory,
                                                     BlockBehaviour.Properties properties) {
        Identifier id = SkyboundMod.id(name);
        // 26.x requires the registry key to be set on the properties BEFORE the block is constructed.
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        T block = factory.apply(properties.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
        BlockItem item = new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);

        ALL.add(block);
        return block;
    }
}
