# Skybound (Phase 1) - Fabric mod for Minecraft 26.3

Requires: Java 25, Fabric Loader, Fabric API 0.161.0+26.3.

## What is in Phase 1
- Blocks: Cloudstone, Storm Cloudstone, Cloudstone Bricks, Starglass, Zephyr Crystal, Skyroot Planks
- Vertical slabs (21): 17 vanilla materials + the 4 new solid blocks. Crafted from 3 blocks in a column (gives 6).
  Placing: click a wall to hug it; click floor/ceiling to use the direction you face; place a second one in the open half to make a full block.
- Items: Chronoshard, Skyflower, Glaive
- Skyreach dimension "skybound:skyreach": End-style floating islands under an Overworld sky.
  Right-click a Skyflower to travel there (a cloudstone platform is built at 0,89,0). Right-click again inside the Skyreach to return near the Overworld origin.
- English and Brazilian Portuguese language files; recipes for everything.

## Build
Recommended: generate a fresh project at https://fabricmc.net/develop/template (mod id: skybound, package: com.skybound, Minecraft 26.3),
then copy `src/` from this folder over the generated one. That gives you the correct Gradle wrapper and Loom/Loader versions.
Or use this folder directly: `gradle wrapper --gradle-version 9.4.0` then `./gradlew build` (jar in build/libs).

## Regenerating assets
`python3 tools_gen_resources.py` (needs Pillow) rewrites all JSON and the placeholder textures into src/main/resources.
The block list in tools_gen_resources.py (VSLABS) must stay in the same order as the `bases.put(...)` list in ModBlocks.java.
Textures are procedurally generated placeholders; replace them with real art any time.

## Not yet written (later phases)
End Reborn (biomes, Warden of the Last Hour), Skyreach biomes/structures/Sky Villages/Storm Citadel/The Tempest,
all new mobs, seasons, weather events, Barometer, minecart upgrades, Mushroom Fields overhaul, Community Board.
