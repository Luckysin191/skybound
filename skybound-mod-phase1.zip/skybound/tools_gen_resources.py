import json, os, random
from PIL import Image

ROOT = "/home/claude/skybound"
RES = f"{ROOT}/src/main/resources"
MOD = "skybound"
random.seed(26)


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------- definitions
# own full blocks: id -> (en, pt)
OWN_BLOCKS = {
    "cloudstone": ("Cloudstone", "Pedra de Nuvem"),
    "storm_cloudstone": ("Storm Cloudstone", "Pedra de Nuvem Tempestuosa"),
    "cloudstone_bricks": ("Cloudstone Bricks", "Tijolos de Pedra de Nuvem"),
    "starglass": ("Starglass", "Vidro Estelar"),
    "zephyr_crystal": ("Zephyr Crystal", "Cristal Zéfiro"),
    "skyroot_planks": ("Skyroot Planks", "Tábuas de Raiz-do-Céu"),
}

OWN_ITEMS = {
    "chronoshard": ("Chronoshard", "Cronofragmento"),
    "skyflower": ("Skyflower", "Flor-do-Céu"),
    "glaive": ("Glaive", "Glaive"),
}

# vertical slabs: base id, texture, en name, pt name, tool (pickaxe/axe)
VSLABS = [
    ("stone", "minecraft:block/stone", "Stone", "Pedra", "pickaxe"),
    ("cobblestone", "minecraft:block/cobblestone", "Cobblestone", "Pedregulho", "pickaxe"),
    ("stone_bricks", "minecraft:block/stone_bricks", "Stone Bricks", "Tijolos de Pedra", "pickaxe"),
    ("bricks", "minecraft:block/bricks", "Bricks", "Tijolos", "pickaxe"),
    ("nether_bricks", "minecraft:block/nether_bricks", "Nether Bricks", "Tijolos do Nether", "pickaxe"),
    ("end_stone_bricks", "minecraft:block/end_stone_bricks", "End Stone Bricks", "Tijolos de Pedra do End", "pickaxe"),
    ("deepslate_bricks", "minecraft:block/deepslate_bricks", "Deepslate Bricks", "Tijolos de Ardósia Abissal", "pickaxe"),
    ("purpur_block", "minecraft:block/purpur_block", "Purpur", "Purpur", "pickaxe"),
    ("oak_planks", "minecraft:block/oak_planks", "Oak", "Carvalho", "axe"),
    ("spruce_planks", "minecraft:block/spruce_planks", "Spruce", "Pinheiro", "axe"),
    ("birch_planks", "minecraft:block/birch_planks", "Birch", "Bétula", "axe"),
    ("jungle_planks", "minecraft:block/jungle_planks", "Jungle", "Selva", "axe"),
    ("acacia_planks", "minecraft:block/acacia_planks", "Acacia", "Acácia", "axe"),
    ("dark_oak_planks", "minecraft:block/dark_oak_planks", "Dark Oak", "Carvalho Escuro", "axe"),
    ("mangrove_planks", "minecraft:block/mangrove_planks", "Mangrove", "Mangue", "axe"),
    ("cherry_planks", "minecraft:block/cherry_planks", "Cherry", "Cerejeira", "axe"),
    ("bamboo_planks", "minecraft:block/bamboo_planks", "Bamboo", "Bambu", "axe"),
    # own blocks
    ("cloudstone", f"{MOD}:block/cloudstone", "Cloudstone", "Pedra de Nuvem", "pickaxe"),
    ("storm_cloudstone", f"{MOD}:block/storm_cloudstone", "Storm Cloudstone", "Pedra de Nuvem Tempestuosa", "pickaxe"),
    ("cloudstone_bricks", f"{MOD}:block/cloudstone_bricks", "Cloudstone Bricks", "Tijolos de Pedra de Nuvem", "pickaxe"),
    ("skyroot_planks", f"{MOD}:block/skyroot_planks", "Skyroot", "Raiz-do-Céu", "axe"),
]

# ---------------------------------------------------------------- textures
def tex_path(kind, name):
    p = f"{RES}/assets/{MOD}/textures/{kind}/{name}.png"
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def noisy(base, var, n=16):
    img = Image.new("RGBA", (n, n))
    px = img.load()
    for x in range(n):
        for y in range(n):
            d = random.randint(-var, var)
            px[x, y] = tuple(max(0, min(255, c + d)) for c in base) + (255,)
    return img


def make_block_textures():
    img = noisy((236, 240, 248), 8)
    img.save(tex_path("block", "cloudstone"))

    img = noisy((92, 100, 122), 10)
    px = img.load()
    for _ in range(14):  # lightning flecks
        px[random.randrange(16), random.randrange(16)] = (230, 220, 120, 255)
    img.save(tex_path("block", "storm_cloudstone"))

    img = noisy((222, 228, 240), 6)
    px = img.load()
    for i in range(16):
        for j in (0, 8):
            px[i, j] = (150, 158, 178, 255)
        for j in range(0, 8):
            px[0 if True else 0, j] = (150, 158, 178, 255)
        for j in range(8, 16):
            px[8, j] = (150, 158, 178, 255)
    img.save(tex_path("block", "cloudstone_bricks"))

    # starglass: cutout (fully opaque frame/shine, transparent centre)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for i in range(16):
        for j in range(16):
            if i in (0, 15) or j in (0, 15):
                px[i, j] = (190, 170, 255, 255)
    for k in range(3, 7):
        px[k, k] = (255, 255, 255, 255)
    for (x, y) in [(10, 5), (4, 11), (12, 12), (7, 9)]:
        px[x, y] = (255, 240, 150, 255)
    img.save(tex_path("block", "starglass"))

    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for i in range(16):
        for j in range(16):
            dist = abs(i - 7.5) + abs(j - 7.5)
            c = int(max(0, 255 - dist * 12))
            px[i, j] = (60 + c // 3, 160 + c // 4, 200 + c // 5, 255)
    img.save(tex_path("block", "zephyr_crystal"))

    img = noisy((214, 190, 150), 6)
    px = img.load()
    for j in (3, 7, 11, 15):
        for i in range(16):
            px[i, j] = (170, 145, 105, 255)
    img.save(tex_path("block", "skyroot_planks"))


def make_item_textures():
    # chronoshard: purple-blue diamond shard
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for i in range(16):
        for j in range(16):
            d = abs(i - 7.5) / 3.5 + abs(j - 7.5) / 6.5
            if d < 1:
                shade = int(255 - d * 110)
                px[i, j] = (110 + shade // 4, 90 + shade // 5, shade, 255)
    px[7, 5] = px[8, 5] = (255, 255, 255, 255)
    img.save(tex_path("item", "chronoshard"))

    # skyflower: stem + petals
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for j in range(9, 16):
        px[8, j] = (70, 170, 80, 255)
    px[7, 12] = px[9, 11] = (70, 170, 80, 255)
    for (x, y) in [(8, 4), (8, 6), (6, 5), (10, 5), (7, 4), (9, 4), (7, 6), (9, 6)]:
        px[x, y] = (150, 220, 255, 255)
    px[8, 5] = (255, 230, 90, 255)
    img.save(tex_path("item", "skyflower"))

    # glaive: diagonal pole with blade
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for k in range(16):
        px[k, 15 - k] = (120, 80, 45, 255)
    for k in range(9, 15):
        for w in range(0, 3):
            x, y = k + w - 1, 15 - k
            if 0 <= x < 16 and 0 <= y < 16:
                px[x, y] = (205, 215, 230, 255)
    for k in range(10, 15):
        x, y = k - 2, 15 - k - 1
        if 0 <= x < 16 and 0 <= y < 16:
            px[x, y] = (240, 245, 255, 255)
    img.save(tex_path("item", "glaive"))


# ---------------------------------------------------------------- json assets
def item_def(name, model):
    write_json(f"{RES}/assets/{MOD}/items/{name}.json",
               {"model": {"type": "minecraft:model", "model": model}})


def make_assets():
    # plain blocks
    for name in OWN_BLOCKS:
        write_json(f"{RES}/assets/{MOD}/blockstates/{name}.json",
                   {"variants": {"": {"model": f"{MOD}:block/{name}"}}})
        write_json(f"{RES}/assets/{MOD}/models/block/{name}.json",
                   {"parent": "minecraft:block/cube_all", "textures": {"all": f"{MOD}:block/{name}"}})
        item_def(name, f"{MOD}:block/{name}")

    # items
    for name, parent in (("chronoshard", "minecraft:item/generated"),
                         ("skyflower", "minecraft:item/generated"),
                         ("glaive", "minecraft:item/handheld")):
        write_json(f"{RES}/assets/{MOD}/models/item/{name}.json",
                   {"parent": parent, "textures": {"layer0": f"{MOD}:item/{name}"}})
        item_def(name, f"{MOD}:item/{name}")

    # vertical slabs
    for base, tex, _en, _pt, _tool in VSLABS:
        vid = f"{base}_vertical_slab"
        faces = {
            "down": {"uv": [0, 0, 16, 8], "texture": "#all", "cullface": "down"},
            "up": {"uv": [0, 0, 16, 8], "texture": "#all", "cullface": "up"},
            "north": {"uv": [0, 0, 16, 16], "texture": "#all", "cullface": "north"},
            "south": {"uv": [0, 0, 16, 16], "texture": "#all"},
            "west": {"uv": [0, 0, 8, 16], "texture": "#all", "cullface": "west"},
            "east": {"uv": [8, 0, 16, 16], "texture": "#all", "cullface": "east"},
        }
        write_json(f"{RES}/assets/{MOD}/models/block/{vid}.json", {
            "textures": {"all": tex, "particle": tex},
            "elements": [{"from": [0, 0, 0], "to": [16, 16, 8], "faces": faces}],
        })
        write_json(f"{RES}/assets/{MOD}/models/block/{vid}_double.json", {
            "parent": "minecraft:block/cube_all", "textures": {"all": tex}})
        variants = {}
        for facing, rot in (("north", 0), ("east", 90), ("south", 180), ("west", 270)):
            v = {"model": f"{MOD}:block/{vid}"}
            if rot:
                v["y"] = rot
            variants[f"double=false,facing={facing}"] = v
            variants[f"double=true,facing={facing}"] = {"model": f"{MOD}:block/{vid}_double"}
        write_json(f"{RES}/assets/{MOD}/blockstates/{vid}.json", {"variants": variants})
        item_def(vid, f"{MOD}:block/{vid}")


def make_lang():
    en, pt = {}, {}
    for k, (e, p) in OWN_BLOCKS.items():
        en[f"block.{MOD}.{k}"] = e
        pt[f"block.{MOD}.{k}"] = p
    for k, (e, p) in OWN_ITEMS.items():
        en[f"item.{MOD}.{k}"] = e
        pt[f"item.{MOD}.{k}"] = p
    for base, _t, e, p, _tool in VSLABS:
        en[f"block.{MOD}.{base}_vertical_slab"] = f"{e} Vertical Slab"
        pt[f"block.{MOD}.{base}_vertical_slab"] = f"Laje Vertical de {p}"
    write_json(f"{RES}/assets/{MOD}/lang/en_us.json", en)
    write_json(f"{RES}/assets/{MOD}/lang/pt_br.json", pt)


# ---------------------------------------------------------------- data
def self_loot(block_id, double_aware=False):
    entry = {"type": "minecraft:item", "name": f"{MOD}:{block_id}"}
    if double_aware:
        entry["functions"] = [{
            "function": "minecraft:set_count", "count": 2, "add": False,
            "conditions": [{
                "condition": "minecraft:block_state_property",
                "block": f"{MOD}:{block_id}",
                "properties": {"double": "true"}}]}]
    return {
        "type": "minecraft:block",
        "pools": [{"rolls": 1, "bonus_rolls": 0, "entries": [entry],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}],
        "random_sequence": f"{MOD}:blocks/{block_id}",
    }


def shaped(path, key, pattern, result, count=1, category="misc"):
    write_json(f"{RES}/data/{MOD}/recipe/{path}.json", {
        "type": "minecraft:crafting_shaped", "category": category,
        "key": key, "pattern": pattern,
        "result": {"id": result, "count": count}})


def shapeless(path, ingredients, result, count=1, category="misc"):
    write_json(f"{RES}/data/{MOD}/recipe/{path}.json", {
        "type": "minecraft:crafting_shapeless", "category": category,
        "ingredients": ingredients,
        "result": {"id": result, "count": count}})


def make_data():
    pick, axe = [], []
    for name in OWN_BLOCKS:
        write_json(f"{RES}/data/{MOD}/loot_table/blocks/{name}.json", self_loot(name))
        (axe if name == "skyroot_planks" else pick).append(f"{MOD}:{name}")
    for base, _t, _e, _p, tool in VSLABS:
        vid = f"{base}_vertical_slab"
        write_json(f"{RES}/data/{MOD}/loot_table/blocks/{vid}.json", self_loot(vid, True))
        (axe if tool == "axe" else pick).append(f"{MOD}:{vid}")
        full = f"{MOD}:{base}" if base in OWN_BLOCKS else f"minecraft:{base}"
        shaped(f"{vid}", {"#": full}, ["#", "#", "#"], f"{MOD}:{vid}", 6, "building")

    write_json(f"{RES}/data/minecraft/tags/block/mineable/pickaxe.json", {"values": pick})
    write_json(f"{RES}/data/minecraft/tags/block/mineable/axe.json", {"values": axe})

    # own recipes
    shaped("cloudstone_bricks", {"#": f"{MOD}:cloudstone"}, ["##", "##"], f"{MOD}:cloudstone_bricks", 4, "building")
    shapeless("storm_cloudstone", [f"{MOD}:cloudstone", "minecraft:coal"], f"{MOD}:storm_cloudstone", 2, "building")
    shapeless("skyroot_planks", ["minecraft:oak_planks", f"{MOD}:cloudstone"], f"{MOD}:skyroot_planks", 2, "building")
    shapeless("starglass", ["minecraft:glass", "minecraft:amethyst_shard"], f"{MOD}:starglass", 1, "building")
    shapeless("zephyr_crystal", ["minecraft:amethyst_block", "minecraft:feather"], f"{MOD}:zephyr_crystal", 1, "building")
    shapeless("chronoshard", ["minecraft:clock", "minecraft:amethyst_shard"], f"{MOD}:chronoshard", 1)
    shapeless("skyflower", ["minecraft:azure_bluet", f"{MOD}:cloudstone", "minecraft:amethyst_shard"], f"{MOD}:skyflower", 1)
    shaped("glaive", {"I": "minecraft:iron_ingot", "C": f"{MOD}:chronoshard", "S": "minecraft:stick"},
           ["I", "C", "S"], f"{MOD}:glaive", 1, "equipment")

    # Skyreach dimension: only references vanilla registry entries on purpose (safest across versions)
    write_json(f"{RES}/data/{MOD}/dimension/skyreach.json", {
        "type": "minecraft:overworld",
        "generator": {
            "type": "minecraft:noise",
            "settings": "minecraft:end",
            "biome_source": {"type": "minecraft:the_end"}}})


if __name__ == "__main__":
    make_block_textures()
    make_item_textures()
    make_assets()
    make_lang()
    make_data()
    print("done")
